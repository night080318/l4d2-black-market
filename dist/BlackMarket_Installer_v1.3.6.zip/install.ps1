﻿# 黑市 Black Market - L4D2 一键安装
# 用法: powershell -ExecutionPolicy Bypass -File install.ps1

param(
    [string]$GamePath = "",
    [switch]$Yes,
    [switch]$NoPause
)

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $here "payload"

function Finish { if (-not $NoPause) { Read-Host "按回车退出" } }

function Step($m) { Write-Host "[*] $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "[+] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "[!] $m" -ForegroundColor Yellow }
function Fail($m) { Write-Host "[x] $m" -ForegroundColor Red }

Write-Host ""
Write-Host "  ==========================================" -ForegroundColor DarkYellow
Write-Host "     L4D2  黑市 Black Market   一键安装" -ForegroundColor DarkYellow
Write-Host "  ==========================================" -ForegroundColor DarkYellow
Write-Host ""

if (-not (Test-Path $payload)) {
    Fail "找不到 payload 目录，压缩包可能没解压完整。"
    Finish
    exit 1
}

# ---------------------------------------------------------------- 找游戏
function Find-L4D2 {
    $cands = @()
    if ($GamePath) { $cands += $GamePath }

    try {
        $proc = Get-Process -Name "left4dead2" -ErrorAction Stop | Select-Object -First 1
        if ($proc -and $proc.Path) { $cands += (Split-Path -Parent $proc.Path) }
    } catch {}

    $steam = $null
    try { $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath } catch {}
    if (-not $steam) {
        try { $steam = (Get-ItemProperty 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction Stop).InstallPath } catch {}
    }

    $libs = @()
    if ($steam) {
        $libs += $steam
        $vdf = Join-Path $steam "steamapps\libraryfolders.vdf"
        if (Test-Path $vdf) {
            $matches2 = Select-String -Path $vdf -Pattern '"path"\s+"([^"]+)"' -AllMatches
            foreach ($line in $matches2) {
                foreach ($m in $line.Matches) { $libs += ($m.Groups[1].Value -replace '\\\\', '\') }
            }
        }
    }
    foreach ($l in $libs) { $cands += (Join-Path $l "steamapps\common\Left 4 Dead 2") }

    foreach ($c in $cands) {
        if ($c -and (Test-Path (Join-Path $c "left4dead2.exe"))) { return $c }
    }
    return $null
}

Step "正在查找 Left 4 Dead 2 ..."
$game = Find-L4D2

if (-not $game) {
    Warn "没有自动找到游戏目录。"
    Write-Host "     （Steam 里右键 L4D2 -> 管理 -> 浏览本地文件，把地址栏路径复制过来）"
    $input_path = Read-Host "请粘贴 Left 4 Dead 2 文件夹路径"
    $game = $input_path.Trim().Trim('"').Trim("'")
}

if (-not $game -or -not (Test-Path (Join-Path $game "left4dead2.exe"))) {
    Fail "这个路径下没有 left4dead2.exe，不是游戏根目录。"
    Finish
    exit 1
}

$target = Join-Path $game "left4dead2"
Ok "游戏目录: $game"

# ---------------------------------------------------------------- 检查游戏是否在跑
if (Get-Process -Name "left4dead2" -ErrorAction SilentlyContinue) {
    Warn "游戏正在运行，请先完全退出 Left 4 Dead 2 再装，否则文件会被占用。"
    if (-not $Yes) {
        $c = Read-Host "已经退出了吗？输入 y 继续，其他键退出"
        if ($c -ne "y") { exit 1 }
    }
}

# ---------------------------------------------------------------- 判断是否已有 SourceMod
$hasSM = Test-Path (Join-Path $target "addons\sourcemod\bin\sourcemod.2.l4d2.dll")
$mode = "full"

if ($hasSM) {
    Ok "检测到你已经装过 SourceMod。"
    $mode = "plugin"
    if (-not $Yes) {
        $c = Read-Host "只安装黑市插件、不动你现有的 SourceMod？(Y/n)"
        if ($c -eq "n") { $mode = "full" }
    }
}

# ---------------------------------------------------------------- 安装
try {
    if ($mode -eq "full") {
        Step "安装 MetaMod + SourceMod + 黑市插件 ..."

        $mmVdf = Join-Path $target "addons\metamod.vdf"
        if (Test-Path $mmVdf) {
            Copy-Item $mmVdf "$mmVdf.bak" -Force
        }

        Copy-Item -Path (Join-Path $payload "*") -Destination $target -Recurse -Force
    }
    else {
        Step "只安装黑市插件 ..."
        $plugDir = Join-Path $target "addons\sourcemod\plugins"
        if (-not (Test-Path $plugDir)) { New-Item -ItemType Directory -Path $plugDir -Force | Out-Null }
        Copy-Item (Join-Path $payload "addons\sourcemod\plugins\l4d2_black_market.smx") $plugDir -Force

        $cfgDir = Join-Path $target "cfg\sourcemod"
        if (-not (Test-Path $cfgDir)) { New-Item -ItemType Directory -Path $cfgDir -Force | Out-Null }
        Copy-Item (Join-Path $payload "cfg\sourcemod\l4d2_black_market.cfg") $cfgDir -Force
    }
}
catch {
    Fail "复制文件失败: $($_.Exception.Message)"
    Finish
    exit 1
}

# ---------------------------------------------------------------- 校验
$smx = Join-Path $target "addons\sourcemod\plugins\l4d2_black_market.smx"
$cfg = Join-Path $target "cfg\sourcemod\l4d2_black_market.cfg"

if (-not (Test-Path $smx)) {
    Fail "安装后没找到 $smx"
    Finish
    exit 1
}

Ok "插件: $((Get-Item $smx).Length) 字节"
if (Test-Path $cfg) { Ok "配置: $cfg" }

# ---------------------------------------------------------------- 收尾提示
Write-Host ""
Write-Host "  ==========================================" -ForegroundColor DarkYellow
Write-Host "   安装完成，还差最后一步" -ForegroundColor DarkYellow
Write-Host "  ==========================================" -ForegroundColor DarkYellow
Write-Host ""
Write-Host "  L4D2 必须用 -insecure 启动，否则不会加载任何插件。"
Write-Host ""
Write-Host "  1. Steam 库 -> 右键 Left 4 Dead 2 -> 属性"
Write-Host "  2. 通用 -> 启动选项，填： -insecure"
Write-Host "  3. 启动游戏，控制台输入： map c1m1_hotel"
Write-Host "  4. 再看： sm plugins list   应该出现 Black Market"
Write-Host ""
Write-Host "  进图后聊天框打 !shop 就能开商店。"
Write-Host ""

Finish
