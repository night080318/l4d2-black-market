﻿L4D2 黑市 Black Market —— 一键安装包
========================================

怎么用
------
1. 双击 INSTALL.bat
2. 它会自动找你 Steam 里的 Left 4 Dead 2
   （找不到就手动粘贴游戏文件夹路径）
3. 装完按提示，在 Steam 启动选项里加 -insecure
4. 进游戏控制台输入 map c1m1_hotel
5. 聊天框打 !shop

注意
----
- 装之前把游戏关掉
- 已经装过 SourceMod 的，脚本会问你要不要覆盖；选 n 只装黑市插件
- -insecure 会关闭 VAC，之后就进不了别人的 VAC 服务器
  想打匹配就把启动选项清空

卸载
----
删掉这两个文件即可（配置和存档可以留着）：
  left4dead2\addons\sourcemod\plugins\l4d2_black_market.smx
  left4dead2\cfg\sourcemod\l4d2_black_market.cfg
