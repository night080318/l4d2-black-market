@echo off
chcp 65001 >nul
title L4D2 Black Market Installer
cd /d "%~dp0"

where powershell >nul 2>nul
if errorlevel 1 (
    echo.
    echo [x] Windows PowerShell not found. Windows 7 SP1 or newer is required.
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
    echo.
    echo [x] Installer exited with an error.
    pause
)
